// Image slider ================>
let slider = tns (
    {
       container : ".my-slider",
       "slideBy" : "1",
       "speed" : 400,
       "nav" : false,
       autoplay : true,
       controls : false,
       autoplayButtonOutput : false,
       responsive: {
        1600: {
            items : 4,
            gutter: 20
        },
        1024: {
            items : 3,
            gutter : 20
        },
        786: {
            items : 2,
            gutter: 20
        },
        480: {
            items : 1,
        }
    } 
})

// Today's Date and time ==============>
var date = new Date();
	document.getElementById("dateTime").innerHTML = date;

// Geolocation
function geo() {
    if(navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showLocation)
    } else {
        document.getElementById("result3").innerHTML = "Geolocation is not supported by your browser.";
    }
}

function showLocation(position) {
    document.getElementById("result3").innerHTML = "Latitude: " +
    position.coords.latitude + "<br>Longitude: " + position.coords.longitude;
}

// Go Up ==============>
let mybutton = document.getElementById("myBtn");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
} 